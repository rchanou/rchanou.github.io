Instructions

Run “x2connector.exe” from command line to see all options.

In Fire Daemon your parameters will be similar to the below:

--ip 192.168.0.53 --username Clubspeed --password Sp33dsheet --port 5100 --loop 1

See also:
MyLaps X2 Manager/Tools: http://developer.mylaps.com/tools/Current/

Will need Visual C++ Redistributable (or download from the X2 Server’s IP over HTTP)
http://www.microsoft.com/en-au/download/confirmation.aspx?id=30679